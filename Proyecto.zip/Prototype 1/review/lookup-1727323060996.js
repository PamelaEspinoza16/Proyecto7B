(function(window, undefined) {
  var dictionary = {
    "804d615c-9548-4a97-80df-89b07c292718": "EncuestaServicio",
    "9c5e7ed8-b7d2-4c66-875a-49f6f16a739c": "EncuestaPersonal",
    "f3df55be-9525-4b2c-80d7-3ba3ef4f6b1d": "Inicio de sesion Administrador",
    "e93b6d12-9020-4582-8717-73b7029530b9": "EncuestaCafeteria",
    "7fc27b27-61fa-41e9-8e58-e4fbb5b604f4": "InicioAlumno",
    "cfe81e73-98c0-4832-b8e9-8b65028f7e19": "Preguntas lanzadas correctamente",
    "53c79103-5acc-402b-a6e0-0bb9cef83e48": "Inicio de sesion alumno",
    "9dbede05-af96-476c-b001-6a67c9200237": "InicioAdmin",
    "52857869-d109-4be3-927d-e536db010bbf": "EncuestaComida",
    "df30bd51-1d9a-4b3c-813f-be9ad6be84a8": "EncuestaAdmin",
    "d12245cc-1680-458d-89dd-4f0d7fb22724": "Identificate",
    "e38d7cbb-7d60-4bbe-94b3-68f76e9f2174": "Registrarse",
    "f39803f7-df02-4169-93eb-7547fb8c961a": "Template 1",
    "bb8abf58-f55e-472d-af05-a7d1bb0cc014": "default"
  };

  var uriRE = /^(\/#)?(screens|templates|masters|scenarios)\/(.*)(\.html)?/;
  window.lookUpURL = function(fragment) {
    var matches = uriRE.exec(fragment || "") || [],
        folder = matches[2] || "",
        canvas = matches[3] || "",
        name, url;
    if(dictionary.hasOwnProperty(canvas)) { /* search by name */
      url = folder + "/" + canvas;
    }
    return url;
  };

  window.lookUpName = function(fragment) {
    var matches = uriRE.exec(fragment || "") || [],
        folder = matches[2] || "",
        canvas = matches[3] || "",
        name, canvasName;
    if(dictionary.hasOwnProperty(canvas)) { /* search by name */
      canvasName = dictionary[canvas];
    }
    return canvasName;
  };
})(window);