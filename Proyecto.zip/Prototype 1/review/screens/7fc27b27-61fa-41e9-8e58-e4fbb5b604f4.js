var content='<div class="ui-page " deviceName="web" deviceType="desktop" deviceWidth="1366" deviceHeight="768">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devWeb canvas firer commentable non-processed" alignment="left" name="Template 1"width="1366" height="768">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./review/templates/f39803f7-df02-4169-93eb-7547fb8c961a/style-1727323060996.css" />\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-7fc27b27-61fa-41e9-8e58-e4fbb5b604f4" class="screen growth-vertical devWeb canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="InicioAlumno"width="1366" height="768">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./review/screens/7fc27b27-61fa-41e9-8e58-e4fbb5b604f4/style-1727323060996.css" />\
      <div class="freeLayout">\
      <div id="s-Image" class="image firer ie-background commentable non-processed" customid="Image"   datasizewidth="1364.59px" datasizeheight="768.00px" dataX="0.71" dataY="0.00"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/cfd8262c-f67e-4736-96ea-052c7be88ae4.jpg" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Button_3" class="button multiline manualfit firer click commentable non-processed" customid="Encuesta de Servico"   datasizewidth="310.00px" datasizeheight="95.00px" dataX="495.00" dataY="140.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_3_0">Encuesta de Servico</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Button_4" class="button multiline manualfit firer click commentable non-processed" customid="Encuesta de Personal"   datasizewidth="310.00px" datasizeheight="95.00px" dataX="495.00" dataY="289.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_4_0">Encuesta de Personal</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Button_5" class="button multiline manualfit firer click commentable non-processed" customid="Encuesta de Comida"   datasizewidth="310.00px" datasizeheight="95.00px" dataX="495.00" dataY="431.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_5_0">Encuesta de Comida</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Button_6" class="button multiline manualfit firer click commentable non-processed" customid="Encuesta de Cafeteria"   datasizewidth="310.00px" datasizeheight="95.00px" dataX="495.00" dataY="577.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_6_0">Encuesta de Cafeteria</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Button_7" class="button multiline manualfit firer click commentable non-processed" customid="Cerrar sesion"   datasizewidth="150.00px" datasizeheight="45.00px" dataX="1182.00" dataY="25.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_7_0">Cerrar sesion</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;