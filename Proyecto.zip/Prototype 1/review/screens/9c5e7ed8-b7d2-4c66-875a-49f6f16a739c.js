var content='<div class="ui-page " deviceName="web" deviceType="desktop" deviceWidth="1366" deviceHeight="768">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devWeb canvas firer commentable non-processed" alignment="left" name="Template 1"width="1366" height="768">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./review/templates/f39803f7-df02-4169-93eb-7547fb8c961a/style-1727323060996.css" />\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-9c5e7ed8-b7d2-4c66-875a-49f6f16a739c" class="screen growth-vertical devWeb canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="EncuestaPersonal"width="1366" height="768">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./review/screens/9c5e7ed8-b7d2-4c66-875a-49f6f16a739c/style-1727323060996.css" />\
      <div class="freeLayout">\
      <div id="s-Image" class="image firer ie-background commentable non-processed" customid="Image"   datasizewidth="1364.59px" datasizeheight="768.00px" dataX="0.71" dataY="-0.00"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/cfd8262c-f67e-4736-96ea-052c7be88ae4.jpg" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Button_7" class="button multiline manualfit firer commentable non-processed" customid="Encuesta de Personal"   datasizewidth="310.00px" datasizeheight="95.00px" dataX="528.00" dataY="-0.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_7_0">Encuesta de Personal</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Button_1" class="button multiline manualfit firer click commentable non-processed" customid="Regresar"   datasizewidth="172.00px" datasizeheight="57.00px" dataX="64.00" dataY="639.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_1_0">Regresar</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Select_1" class="dropdown firer commentable non-processed" customid="Select 1"    datasizewidth="472.00px" datasizeheight="45.00px" dataX="98.00" dataY="169.00"  tabindex="-1"><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content icon"><div class="valign"><div class="value">Excelente</div></div></div></div></div><select id="s-Select_1-options" class="s-9c5e7ed8-b7d2-4c66-875a-49f6f16a739c dropdown-options" ><option selected="selected" class="option">Excelente</option>\
      <option  class="option">Bueno</option>\
      <option  class="option">Regular</option>\
      <option  class="option">Malo</option></select></div>\
      <div id="s-Input_text_1" class="text firer commentable non-processed" customid="Input text 1"  datasizewidth="472.00px" datasizeheight="45.00px" dataX="98.00" dataY="124.00" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="1.- &iquest;C&oacute;mo calificar&iacute;as la actitud del personal hacia los estudiantes y clientes??"/></div></div>  </div></div></div>\
      <div id="s-Input_text_2" class="text firer commentable non-processed" customid="Input text 1"  datasizewidth="616.00px" datasizeheight="45.00px" dataX="98.00" dataY="231.00" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="2.- &iquest;El personal te brind&oacute; la ayuda necesaria o aclarar&oacute; tus dudas de manera efectiva?"/></div></div>  </div></div></div>\
      <div id="s-Select_2" class="dropdown firer commentable non-processed" customid="Select 1"    datasizewidth="472.00px" datasizeheight="45.00px" dataX="98.00" dataY="276.00"  tabindex="-1"><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content icon"><div class="valign"><div class="value">Excelente</div></div></div></div></div><select id="s-Select_2-options" class="s-9c5e7ed8-b7d2-4c66-875a-49f6f16a739c dropdown-options" ><option selected="selected" class="option">Excelente</option>\
      <option  class="option">Bueno</option>\
      <option  class="option">Regular</option>\
      <option  class="option">Malo</option></select></div>\
      <div id="s-Input_text_3" class="text firer commentable non-processed" customid="Input text 1"  datasizewidth="609.00px" datasizeheight="45.00px" dataX="98.00" dataY="339.00" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="3.- &iquest;Qu&eacute; tan dispuesto estaba el personal a resolver problemas o imprevistos??"/></div></div>  </div></div></div>\
      <div id="s-Select_3" class="dropdown firer commentable non-processed" customid="Select 1"    datasizewidth="472.00px" datasizeheight="45.00px" dataX="98.00" dataY="384.00"  tabindex="-1"><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content icon"><div class="valign"><div class="value">Excelente</div></div></div></div></div><select id="s-Select_3-options" class="s-9c5e7ed8-b7d2-4c66-875a-49f6f16a739c dropdown-options" ><option selected="selected" class="option">Excelente</option>\
      <option  class="option">Bueno</option>\
      <option  class="option">Regular</option>\
      <option  class="option">Malo</option></select></div>\
      <div id="s-Button_3" class="button multiline manualfit firer click commentable non-processed" customid="Enviar"   datasizewidth="172.00px" datasizeheight="57.00px" dataX="1101.00" dataY="549.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_3_0">Enviar</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;