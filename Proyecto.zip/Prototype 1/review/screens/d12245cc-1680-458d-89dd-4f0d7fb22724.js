var content='<div class="ui-page " deviceName="web" deviceType="desktop" deviceWidth="1366" deviceHeight="768">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devWeb canvas firer commentable non-processed" alignment="left" name="Template 1"width="1366" height="768">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./review/templates/f39803f7-df02-4169-93eb-7547fb8c961a/style-1727323060996.css" />\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-d12245cc-1680-458d-89dd-4f0d7fb22724" class="screen growth-vertical devWeb canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Identificate"width="1366" height="768">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./review/screens/d12245cc-1680-458d-89dd-4f0d7fb22724/style-1727323060996.css" />\
      <link type="text/css" rel="stylesheet" href="./review/screens/d12245cc-1680-458d-89dd-4f0d7fb22724/fonts-1727323060996.css" />\
      <div class="freeLayout">\
      <div id="s-Image" class="image firer ie-background commentable non-processed" customid="Image"   datasizewidth="1364.59px" datasizeheight="768.00px" dataX="0.71" dataY="-0.00"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/cfd8262c-f67e-4736-96ea-052c7be88ae4.jpg" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Text_1" class="richtext manualfit firer ie-background commentable non-processed" customid="IDENTIFICATE"   datasizewidth="362.56px" datasizeheight="55.00px" dataX="536.56" dataY="96.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_1_0">IDENTIFICATE</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Button_3" class="button multiline manualfit firer click commentable non-processed" customid="ALUMNO"   datasizewidth="452.00px" datasizeheight="72.00px" dataX="861.00" dataY="316.50" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_3_0">ALUMNO</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Button_5" class="button multiline manualfit firer click commentable non-processed" customid="ADMINISTRADOR"   datasizewidth="452.00px" datasizeheight="72.00px" dataX="71.00" dataY="316.50" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_5_0">ADMINISTRADOR</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;