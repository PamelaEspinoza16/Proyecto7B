	window.widgets = {
		descriptionMap : widgetDescriptionMap = {},
		rootWidgetMap : widgetRootMap = {}
	};

	widgets.descriptionMap[["s-Image", "804d615c-9548-4a97-80df-89b07c292718"]] = ""; 

			widgets.rootWidgetMap[["s-Image", "804d615c-9548-4a97-80df-89b07c292718"]] = ["Image", "s-Image"]; 

	widgets.descriptionMap[["s-Image", "9c5e7ed8-b7d2-4c66-875a-49f6f16a739c"]] = ""; 

			widgets.rootWidgetMap[["s-Image", "9c5e7ed8-b7d2-4c66-875a-49f6f16a739c"]] = ["Image", "s-Image"]; 

	widgets.descriptionMap[["s-Image", "f3df55be-9525-4b2c-80d7-3ba3ef4f6b1d"]] = ""; 

			widgets.rootWidgetMap[["s-Image", "f3df55be-9525-4b2c-80d7-3ba3ef4f6b1d"]] = ["Image", "s-Image"]; 

	widgets.descriptionMap[["s-Image", "e93b6d12-9020-4582-8717-73b7029530b9"]] = ""; 

			widgets.rootWidgetMap[["s-Image", "e93b6d12-9020-4582-8717-73b7029530b9"]] = ["Image", "s-Image"]; 

	widgets.descriptionMap[["s-Image", "7fc27b27-61fa-41e9-8e58-e4fbb5b604f4"]] = ""; 

			widgets.rootWidgetMap[["s-Image", "7fc27b27-61fa-41e9-8e58-e4fbb5b604f4"]] = ["Image", "s-Image"]; 

	widgets.descriptionMap[["s-Image", "cfe81e73-98c0-4832-b8e9-8b65028f7e19"]] = ""; 

			widgets.rootWidgetMap[["s-Image", "cfe81e73-98c0-4832-b8e9-8b65028f7e19"]] = ["Image", "s-Image"]; 

	widgets.descriptionMap[["s-Image", "53c79103-5acc-402b-a6e0-0bb9cef83e48"]] = ""; 

			widgets.rootWidgetMap[["s-Image", "53c79103-5acc-402b-a6e0-0bb9cef83e48"]] = ["Image", "s-Image"]; 

	widgets.descriptionMap[["s-Image", "9dbede05-af96-476c-b001-6a67c9200237"]] = ""; 

			widgets.rootWidgetMap[["s-Image", "9dbede05-af96-476c-b001-6a67c9200237"]] = ["Image", "s-Image"]; 

	widgets.descriptionMap[["s-Image", "52857869-d109-4be3-927d-e536db010bbf"]] = ""; 

			widgets.rootWidgetMap[["s-Image", "52857869-d109-4be3-927d-e536db010bbf"]] = ["Image", "s-Image"]; 

	widgets.descriptionMap[["s-Image", "df30bd51-1d9a-4b3c-813f-be9ad6be84a8"]] = ""; 

			widgets.rootWidgetMap[["s-Image", "df30bd51-1d9a-4b3c-813f-be9ad6be84a8"]] = ["Image", "s-Image"]; 

	widgets.descriptionMap[["s-Image", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Image", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Image", "s-Image"]; 

	widgets.descriptionMap[["s-Image", "e38d7cbb-7d60-4bbe-94b3-68f76e9f2174"]] = ""; 

			widgets.rootWidgetMap[["s-Image", "e38d7cbb-7d60-4bbe-94b3-68f76e9f2174"]] = ["Image", "s-Image"]; 

	