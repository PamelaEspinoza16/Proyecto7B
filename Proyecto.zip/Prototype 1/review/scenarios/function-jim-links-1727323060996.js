(function(window, undefined) {

  var jimLinks = {
    "804d615c-9548-4a97-80df-89b07c292718" : {
      "Button_1" : [
        "7fc27b27-61fa-41e9-8e58-e4fbb5b604f4"
      ],
      "Button_3" : [
        "7fc27b27-61fa-41e9-8e58-e4fbb5b604f4"
      ]
    },
    "9c5e7ed8-b7d2-4c66-875a-49f6f16a739c" : {
      "Button_1" : [
        "7fc27b27-61fa-41e9-8e58-e4fbb5b604f4"
      ],
      "Button_3" : [
        "7fc27b27-61fa-41e9-8e58-e4fbb5b604f4"
      ]
    },
    "f3df55be-9525-4b2c-80d7-3ba3ef4f6b1d" : {
      "Button_1" : [
        "9dbede05-af96-476c-b001-6a67c9200237"
      ],
      "Button_2" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    },
    "e93b6d12-9020-4582-8717-73b7029530b9" : {
      "Button_1" : [
        "7fc27b27-61fa-41e9-8e58-e4fbb5b604f4"
      ],
      "Button_3" : [
        "7fc27b27-61fa-41e9-8e58-e4fbb5b604f4"
      ]
    },
    "7fc27b27-61fa-41e9-8e58-e4fbb5b604f4" : {
      "Button_3" : [
        "804d615c-9548-4a97-80df-89b07c292718"
      ],
      "Button_4" : [
        "9c5e7ed8-b7d2-4c66-875a-49f6f16a739c"
      ],
      "Button_5" : [
        "52857869-d109-4be3-927d-e536db010bbf"
      ],
      "Button_6" : [
        "e93b6d12-9020-4582-8717-73b7029530b9"
      ],
      "Button_7" : [
        "53c79103-5acc-402b-a6e0-0bb9cef83e48"
      ]
    },
    "cfe81e73-98c0-4832-b8e9-8b65028f7e19" : {
      "Button_1" : [
        "9dbede05-af96-476c-b001-6a67c9200237"
      ]
    },
    "53c79103-5acc-402b-a6e0-0bb9cef83e48" : {
      "Button_1" : [
        "7fc27b27-61fa-41e9-8e58-e4fbb5b604f4"
      ],
      "Text_3" : [
        "e38d7cbb-7d60-4bbe-94b3-68f76e9f2174"
      ],
      "Button_2" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    },
    "9dbede05-af96-476c-b001-6a67c9200237" : {
      "Button_6" : [
        "df30bd51-1d9a-4b3c-813f-be9ad6be84a8"
      ],
      "Button_1" : [
        "f3df55be-9525-4b2c-80d7-3ba3ef4f6b1d"
      ]
    },
    "52857869-d109-4be3-927d-e536db010bbf" : {
      "Button_1" : [
        "7fc27b27-61fa-41e9-8e58-e4fbb5b604f4"
      ],
      "Button_3" : [
        "7fc27b27-61fa-41e9-8e58-e4fbb5b604f4"
      ]
    },
    "df30bd51-1d9a-4b3c-813f-be9ad6be84a8" : {
      "Button_1" : [
        "cfe81e73-98c0-4832-b8e9-8b65028f7e19"
      ]
    },
    "d12245cc-1680-458d-89dd-4f0d7fb22724" : {
      "Button_3" : [
        "53c79103-5acc-402b-a6e0-0bb9cef83e48"
      ],
      "Button_5" : [
        "f3df55be-9525-4b2c-80d7-3ba3ef4f6b1d"
      ]
    },
    "e38d7cbb-7d60-4bbe-94b3-68f76e9f2174" : {
      "Button_1" : [
        "53c79103-5acc-402b-a6e0-0bb9cef83e48"
      ]
    }    
  }

  window.jimLinks = jimLinks;
})(window);